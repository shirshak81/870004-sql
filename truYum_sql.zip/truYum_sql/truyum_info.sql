#1.a
insert into menuitems 
(menuITEMId,menuname,menuprice,active,Launchdate,category,freeDelivery,action)
values
(1,"Sandwich",99.00,"Yes",'2017-03-15',"Main Course","Yes","Edit"),
(2,"Burger",129.00,"Yes","2017-12-23","Main Course","No","Edit"),
(3,"Pizza",149.00,"Yes","2017-08-21","Main Course","No","Edit"),
(4,"French Fries",57.00,"No","2017-07-02","Starters","Yes","Edit"),
(5,"Chocolate Brownie",32.00,"Yes","2022-11-02","Dessert","Yes","Edit");

#1.b
SELECT menuname,concat("Rs. ",menuprice) as menuprice,active,Launchdate,category,freeDelivery,action FROM truyum.menuitems;

#2.a
select 
menuname,concat("Rs. ",menuprice) as menuprice,category,freeDelivery,replace(action,'Edit','Add to Cart') as action from truyum.menuitems where Launchdate < "23/12/2017" and active = "Yes";

#3.a
select menuname,concat("Rs. ",menuprice) as menuprice,active,Launchdate,category,freeDelivery,action from truyum.menuitems where menuITEMId=1;

#3.b
update truyum.menuitems set menuname = 'burger',menuprice = 129.00, active = 'yes',Launchdate='23/12/2017',category='Main Course',freeDelivery = 'Yes'where menuITEMId = 1;

#4.a
insert into usertypes 
(userId,userName,userType)
values 
(1,"Shirshak","Admin"),
(2,"Matt","Customer");

insert into cartitems 
(cartId,menuITEMId,userId) 
values
(1,1,2),
(2,2,2),
(3,3,2);

#5.a
select m.menuname, m.freeDelivery, m.menuprice from menuitems m inner join cartitems c on m.menuITEMId=c.menuITEMId inner join usertypes u on c.userId=u.userId
where c.userId=2;

#5.b
select concat("Rs. ",cast(sum(m.menuprice)as char)) as total from menuitems m inner join cartitems c on m.menuITEMId=c.menuITEMId inner join usertypes u on c.userId=u.userId where c.userId=2;

#6.a
delete from cartitems where menuITEMId= 2 and userId = 2;