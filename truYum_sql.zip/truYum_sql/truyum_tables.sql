create database truyum;

create table menuitems(
menuITEMId       int          not null primary key,
menuname         varchar(20)  not null,
menuprice        decimal(10,2) not null,
active       varchar(10)  not null,
Launchdate   date         not null,
category     varchar(30)  not null,
freeDelivery varchar(10)  not null,
action       varchar (10) not null
);


create table usertypes(
userId   int         not null primary key,
userName varchar(30) not null,
userType varchar(30) not null
);


create table cartitems(
cartId int not null primary key,
menuITEMId int,
userId int,
foreign key (userId) REFERENCES usertypes(userId),
foreign key (menuITEMId) references menuitems(menuITEMId)
);